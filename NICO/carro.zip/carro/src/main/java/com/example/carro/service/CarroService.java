package com.example.carro.service;

import com.example.carro.model.Carro;
import com.example.carro.repository.CarroRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.List;
import java.util.Optional;

@Service
public class CarroService {
    @Autowired
    private CarroRepository carroRepository;

    @Autowired
    private RestTemplate restTemplate;

    private final String INVENTORY_URL = "http://localhost:8082/api/inventory";

    public Carro addToCarro(Long userId, Long productId, Integer Quantity) {
        String url = INVENTORY_URL + "/" + productId + "?quantityRequired=" + quantity;
        Boolean isStockAvailable = restTemplate.getForObject(url, Boolean.class);

        if (Boolean.FALSE.equals(isStockAvailable)) {
            throw new RuntimeException("No hay stock suficiente para el producto: " + productId);
        }

        // 2. Si hay stock, verificamos si el producto ya está en el carrito
        Optional<Carro> existingItem = CarroRepository.findByUserIdAndProductId(userId, productId);

        if (existingItem.isPresent()) {
            // Si ya estaba, solo le sumamos la nueva cantidad
            Carro item = existingItem.get();
            item.setQuantity(item.getQuantity() + quantity);
            return carroRepository.save(item);
        } else {
            // Si es nuevo en el carrito, lo creamos
            Carro newItem = new Carro();
            newItem.setUserId(userId);
            newItem.setProductId(productId);
            newItem.setQuantity(quantity);
            return CarroRepository.save(newItem);
        }
    }

    public List<Carro> getCartByUserId(Long userId) {
        return carroRepository.findByUserId(userId);
    }

    public void removeFromCart(Long itemId) {
        carroRepository.deleteById(itemId);
    }
}
